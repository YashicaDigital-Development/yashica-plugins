<?php

/**
 * Plugin Name: Yashica Poukazy
 * Description: Tvorba poukazů
 * Version: 1.0
 * Author: Yashica Digital s.r.o.
 * Author URI: https://www.yashica-digital.cz
 */

if (!class_exists('YashicaPoukazy')) {
    //DELKA POUKAZU
    define('YASHICA_POUKAZY_DEFAULT_DELKA_POUKAZU', 4);
    //UPDATE INFO FILE
    define('YASHICA_POUKAZY_UPDATE_INFO_FILE', 'https://raw.githubusercontent.com/YashicaDigital-Development/yashica-plugins/main/yashica-poukazy/info.json');
    class YashicaPoukazy
    {
        private $yashica_poukazy_options;
        private $yashica_poukazy_produkty;

        public function __construct()
        {
            add_action('wp_ajax_yashica_poukazy_nahledPoukazuAction', array($this, 'yashica_poukazy_nahledPoukazuAction'));
            add_action('admin_enqueue_scripts', array($this, 'yashica_poukazy_link_assets'));
            add_action('admin_menu', array($this, 'yashica_poukazy_add_plugin_page'));
            add_action('admin_init', array($this, 'yashica_poukazy_page_init'));
            add_filter('plugins_api', array($this, 'yashica_poukazy_plugin_info'), 20, 3);
            add_filter('site_transient_update_plugins', array($this, 'yashica_poukazy_push_update'));
            add_filter('woocommerce_email_attachments', array($this, 'yashica_poukazy_attach_pdf_to_emails'), 10, 4);
            add_action('woocommerce_order_status_completed', array($this, 'yashica_poukazy_payment_complete'), 1);
            add_action('woocommerce_admin_order_data_after_order_details', array($this, 'yashica_poukazy_order_meta_general'));
        }
        function yashica_poukazy_attach_pdf_to_emails($attachments, $email_id, $order, $email)
        {
            $email_ids = array('customer_completed_order');
            if (in_array($email_id, $email_ids) && count(get_post_meta($order->get_id(), 'poukaz')) != 0) {
                $rok = date('Y');
                $poukaz_base_path = __DIR__ . '/poukazy/' . $rok;
                if (!file_exists($poukaz_base_path) && !is_dir($poukaz_base_path)) {
                    mkdir($poukaz_base_path);
                }
                $poukazy = get_post_meta($order->get_id(), 'poukaz');
                foreach ($poukazy as $p) {
                    $codeRaw = unserialize($p);
                    $code = $codeRaw[0];
                    $poukaz_path = $poukaz_base_path . '/poukaz_' . $order->get_id() . '_' . $code . '.pdf';
                    $attachments[] = $poukaz_path;
                }
                file_put_contents(__DIR__ . '/logs/' . $rok . '.txt', "\r\n" . date('d-m-Y H:i:s') . "\r\n-----------\r\n", FILE_APPEND);
            }
            return $attachments;
        }

        function yashica_poukazy_order_meta_general($order)
        {
            $poukazy = get_post_meta($order->get_id(), 'poukaz');
            if ($poukazy) {
                echo '<div style="clear:both;"></div><h3>Poukazy</h3><p class="form-field form-field-wide wc-customer-poukazy">';
                foreach ($poukazy as $p) {
                    $codeRaw = unserialize($p);
                    echo $codeRaw[0] . '<br>';
                }
                echo '</p>';
            }
        }
        function yashica_poukazy_payment_complete($order_id)
        {
            $existingPoukazy = get_post_meta($order_id, 'poukaz');
            if (count($existingPoukazy) == 0) {
                $pocet_poukazu = (isset($this->yashica_poukazy_options['pocet_poukazu'])) ? $this->yashica_poukazy_options['pocet_poukazu'] : 0;
                if ($pocet_poukazu) {
                    $order = wc_get_order($order_id);
                    $items = $order->get_items();
                    $rok = date('Y');
                    foreach ($items as $item) {
                        $itemData = $item->get_data();
                        for ($i = 1; $i <= $pocet_poukazu; $i++) {
                            if (isset($this->yashica_poukazy_options['poukaz_activate_' . $i])) {
                                if (isset($this->yashica_poukazy_options['poukaz_produkt_id_' . $i]) && $this->yashica_poukazy_options['poukaz_produkt_id_' . $i] == $itemData['product_id']) {
                                    for ($q = 0; $q < $item->get_quantity(); $q++) {
                                        $poukaz_array = $this->yashica_poukazy_generatePDF(['img_id' => $this->yashica_poukazy_options['poukaz_image_attachment_id_' . $i], 'predpona' => $this->yashica_poukazy_options['poukaz_predpona_' . $i], 'delka' => $this->yashica_poukazy_options['poukaz_delka_' . $i], 'hodnota' => $this->yashica_poukazy_options['poukaz_hodnota_' . $i], 'typ' => $this->yashica_poukazy_options['poukaz_typ_poukazu_' . $i], 'top' => $this->yashica_poukazy_options['poukaz_pozice_top_' . $i], 'left' => $this->yashica_poukazy_options['poukaz_pozice_left_' . $i], 'order_id' => $order_id, 'delka_platnosti' => (isset($this->yashica_poukazy_options['poukaz_delka_platnosti_' . $i])) ? $this->yashica_poukazy_options['poukaz_delka_platnosti_' . $i] : 0], false);
                                        add_post_meta($order_id, 'poukaz', serialize([$poukaz_array['code']]));
                                        file_put_contents(__DIR__ . '/logs/' . $rok . '.txt', print_r($poukaz_array, true), FILE_APPEND);
                                    }
                                }
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
        }
        /* Link sc ripts, styles */
        public function yashica_poukazy_link_assets($hook_suffix)
        {
            if ($hook_suffix != 'toplevel_page_yashica-digital-poukazy') return;
            wp_enqueue_style('select2-css', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css');
            wp_enqueue_script('select2-js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js');
            wp_enqueue_style('yashica_poukazy_styles', plugin_dir_url(__FILE__) . 'css/yashica_poukazy_styles.css');
            wp_enqueue_script('yashica_poukazy_scripts', plugin_dir_url(__FILE__) . 'js/yashica_poukazy_scripts.js', array('jquery'), false, true);
            wp_localize_script(
                'yashica_poukazy_scripts',
                'yashica_poukazy_ajax_object',
                array('ajax_url' => admin_url('admin-ajax.php'))
            );
            wp_enqueue_media();
        }
        /* SETTINGS PAGE */
        public function yashica_poukazy_add_plugin_page()
        {
            add_menu_page(
                'Poukazy - Nastavení',
                'Poukazy - Yashica',
                'manage_options',
                'yashica-digital-poukazy',
                array($this, 'yashica_poukazy_create_admin_page'),
                'dashicons-tickets',

            );
        }
        public function yashica_poukazy_create_admin_page()
        {
?>
            <div class="wrap">
                <h1>Poukazy - Nastavení</h1>

                <?php settings_errors(); ?>

                <form method="post" action="options.php">
                    <?php
                    settings_fields('yashica_poukazy_options_group');
                    do_settings_sections('yashica-poukazy-admin');
                    submit_button();
                    ?>
                </form>
            </div>
        <?php
        }
        public function yashica_poukazy_page_init()
        {
            $this->yashica_poukazy_options = get_option('yashica_poukazy_options');
            $role_object = get_role('editor');
            $role_object->add_cap('edit_theme_options');
            register_setting(
                'yashica_poukazy_options_group',
                'yashica_poukazy_options',
                array($this, 'yashica_poukazy_sanitize')
            );
            add_settings_section(
                'yashica_poukazy_0_setting_section',
                'Počet poukazů',
                array($this, 'yashica_poukazy_0_section_callback'),
                'yashica-poukazy-admin'
            );
            $pocet_poukazu = (isset($this->yashica_poukazy_options['pocet_poukazu'])) ? $this->yashica_poukazy_options['pocet_poukazu'] : 0;

            for ($i = 1; $i <= $pocet_poukazu; $i++) {
                add_settings_section(
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    'Poukaz ' . $i,
                    '',
                    'yashica-poukazy-admin'
                );
                add_settings_field(
                    'poukaz_activate_' . $i,
                    'Aktivovat poukaz',
                    array($this, 'yashica_poukazy_poukaz_activate_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_image_attachment_id_' . $i,
                    'Obrázek poukazu',
                    array($this, 'yashica_poukazy_poukaz_img_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_produkt_id_' . $i,
                    'Produkt',
                    array($this, 'yashica_poukazy_produkt_id_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_hodnota_' . $i,
                    'Hodnota poukazu',
                    array($this, 'yashica_poukazy_poukaz_hodnota_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_typ_poukazu_' . $i,
                    'Typ poukazu',
                    array($this, 'yashica_poukazy_typ_poukazu_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_delka_platnosti_' . $i,
                    'Délka platnosti - počet měsíců',
                    array($this, 'yashica_poukazy_poukaz_delka_platnosti_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_predpona_' . $i,
                    'Předpona kódu',
                    array($this, 'poukaz_predpona_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_delka_' . $i,
                    'Délka poukazu bez předpony',
                    array($this, 'yashica_poukazy_poukaz_delka_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_pozice_top_' . $i,
                    'Pozice kódu - Ze shora',
                    array($this, 'yashica_poukazy_poukaz_pozice_top_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_pozice_left_' . $i,
                    'Pozice kódu - Zleva',
                    array($this, 'yashica_poukazy_poukaz_pozice_left_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
                add_settings_field(
                    'poukaz_nahled_' . $i,
                    '',
                    array($this, 'yashica_poukazy_poukaz_nahled_callback'),
                    'yashica-poukazy-admin',
                    'yashica_poukazy_poukaz_' . $i . '_setting_section',
                    array('input_number' => $i)
                );
            }
        }
        public function yashica_poukazy_sanitize($input)
        {

            $sanitary_values = array();
            $pocet_poukazu = 0;
            if (isset($input['pocet_poukazu'])) {
                $sanitary_values['pocet_poukazu'] = sanitize_text_field($input['pocet_poukazu']);
                $pocet_poukazu = $sanitary_values['pocet_poukazu'];
            }
            for ($i = 1; $i <= $pocet_poukazu; $i++) {
                if (isset($input['poukaz_activate_' . $i])) {
                    $sanitary_values['poukaz_activate_' . $i] = sanitize_text_field($input['poukaz_activate_' . $i]);

                    if (isset($input['poukaz_image_attachment_id_' . $i])) {
                        $sanitary_values['poukaz_image_attachment_id_' . $i] = sanitize_text_field($input['poukaz_image_attachment_id_' . $i]);
                    }
                    if (isset($input['poukaz_predpona_' . $i])) {
                        $sanitary_values['poukaz_predpona_' . $i] = sanitize_text_field($input['poukaz_predpona_' . $i]);
                    }
                    if (isset($input['poukaz_produkt_id_' . $i])) {
                        $sanitary_values['poukaz_produkt_id_' . $i] = sanitize_text_field($input['poukaz_produkt_id_' . $i]);
                    }
                    if (isset($input['poukaz_delka_' . $i])) {
                        $sanitary_values['poukaz_delka_' . $i] = sanitize_text_field($input['poukaz_delka_' . $i]);
                    }
                    if (isset($input['poukaz_hodnota_' . $i])) {
                        $sanitary_values['poukaz_hodnota_' . $i] = sanitize_text_field($input['poukaz_hodnota_' . $i]);
                    }
                    if (isset($input['poukaz_typ_poukazu_' . $i])) {
                        $sanitary_values['poukaz_typ_poukazu_' . $i] = sanitize_text_field($input['poukaz_typ_poukazu_' . $i]);
                    }
                    if (isset($input['poukaz_pozice_top_' . $i])) {
                        $sanitary_values['poukaz_pozice_top_' . $i] = sanitize_text_field($input['poukaz_pozice_top_' . $i]);
                    }
                    if (isset($input['poukaz_pozice_left_' . $i])) {
                        $sanitary_values['poukaz_pozice_left_' . $i] = sanitize_text_field($input['poukaz_pozice_left_' . $i]);
                    }
                    if (isset($input['poukaz_delka_platnosti_' . $i])) {
                        $sanitary_values['poukaz_delka_platnosti_' . $i] = sanitize_text_field($input['poukaz_delka_platnosti_' . $i]);
                    }
                }
            }


            return $sanitary_values;
        }


        function yashica_poukazy_0_section_callback()
        {
            $this->yashica_poukazy_produkty = wc_get_products([]);
            printf(
                '<input class="small-text pocet_poukazu" type="number" step="1" name="yashica_poukazy_options[pocet_poukazu]" id="pocet_poukazu" value="%s">',
                isset($this->yashica_poukazy_options['pocet_poukazu']) ? esc_attr($this->yashica_poukazy_options['pocet_poukazu']) : 0
            );
        }
        function yashica_poukazy_poukaz_activate_callback(array $args)
        {
            printf(
                '<input class="poukaz_activate" type="checkbox" name="yashica_poukazy_options[poukaz_activate_' . $args['input_number'] . ']" id="poukaz_activate_' . $args['input_number'] . '" value="1" %s>',
                (isset($this->yashica_poukazy_options['poukaz_activate_' . $args['input_number']]) && $this->yashica_poukazy_options['poukaz_activate_' . $args['input_number']] == 1) ? 'checked' : ''
            );
        }
        function yashica_poukazy_poukaz_delka_platnosti_callback(array $args)
        {
            printf(
                '<input class="small-text poukaz_delka_platnosti" type="number" name="yashica_poukazy_options[poukaz_delka_platnosti_' . $args['input_number'] . ']" id="poukaz_delka_platnosti_' . $args['input_number'] . '" value="%s">',
                isset($this->yashica_poukazy_options['poukaz_delka_platnosti_' . $args['input_number']]) ? esc_attr($this->yashica_poukazy_options['poukaz_delka_platnosti_' . $args['input_number']]) : ''
            );
        }
        function yashica_poukazy_poukaz_pozice_left_callback(array $args)
        {
            printf(
                '<input class="small-text poukaz_pozice_left" type="number" step="1" name="yashica_poukazy_options[poukaz_pozice_left_' . $args['input_number'] . ']" id="poukaz_pozice_left_' . $args['input_number'] . '" value="%s">',
                isset($this->yashica_poukazy_options['poukaz_pozice_left_' . $args['input_number']]) ? esc_attr($this->yashica_poukazy_options['poukaz_pozice_left_' . $args['input_number']]) : ''
            );
        }

        function yashica_poukazy_poukaz_pozice_top_callback(array $args)
        {
            printf(
                '<input class="small-text poukaz_pozice_top" type="number" step="1" name="yashica_poukazy_options[poukaz_pozice_top_' . $args['input_number'] . ']" id="poukaz_pozice_top_' . $args['input_number'] . '" value="%s">',
                isset($this->yashica_poukazy_options['poukaz_pozice_top_' . $args['input_number']]) ? esc_attr($this->yashica_poukazy_options['poukaz_pozice_top_' . $args['input_number']]) : ''
            );
        }

        function yashica_poukazy_poukaz_nahled_callback(array $args)
        {
            echo '<button class="button poukaz_nahled_btn" type="button" name="poukaz_nahled_' . $args['input_number'] . '_btn" id="poukaz_nahled_' . $args['input_number'] . '_btn">Náhled</button>';
        }

        function yashica_poukazy_poukaz_hodnota_callback(array $args)
        {
            printf(
                '<input class="small-text poukaz_hodnota" type="number" step="1" name="yashica_poukazy_options[poukaz_hodnota_' . $args['input_number'] . ']" id="poukaz_hodnota_' . $args['input_number'] . '" value="%s">',
                isset($this->yashica_poukazy_options['poukaz_hodnota_' . $args['input_number']]) ? esc_attr($this->yashica_poukazy_options['poukaz_hodnota_' . $args['input_number']]) : ''
            );
        }

        function yashica_poukazy_poukaz_delka_callback(array $args)
        {
            printf(
                '<input class="small-text poukaz_delka" type="number" min="4" name="yashica_poukazy_options[poukaz_delka_' . $args['input_number'] . ']" id="poukaz_delka_' . $args['input_number'] . '" value="%s">',
                isset($this->yashica_poukazy_options['poukaz_delka_' . $args['input_number']]) ? esc_attr($this->yashica_poukazy_options['poukaz_delka_' . $args['input_number']]) : YASHICA_POUKAZY_DEFAULT_DELKA_POUKAZU
            );
        }

        function yashica_poukazy_produkt_id_callback(array $args)
        {
            $selected_produkt_id = (isset($this->yashica_poukazy_options['poukaz_produkt_id_' . $args['input_number']]) && $this->yashica_poukazy_options['poukaz_produkt_id_' . $args['input_number']]) ? $this->yashica_poukazy_options['poukaz_produkt_id_' . $args['input_number']] : 0;
        ?>
            <select class="poukaz_produkt_id_select" name="yashica_poukazy_options[poukaz_produkt_id_<?php echo $args['input_number']; ?>]" id="poukaz_produkt_id_<?php echo $args['input_number']; ?>">
                <option value="0" <?php echo ($selected_produkt_id == 0) ? 'selected' : ''; ?> disabled>Přiřaďte poukaz</option>
                <?php
                if ($this->yashica_poukazy_produkty) {
                    foreach ($this->yashica_poukazy_produkty as $produkt) :
                        $produkt_id = $produkt->get_id();
                        $selected = '';
                        if ($produkt_id == $selected_produkt_id) {
                            $selected = 'selected';
                        }
                        printf('<option value="%1$s" %3$s>%2$s</option>', $produkt_id, $produkt->get_name(), $selected);
                    endforeach;
                }
                ?>

            </select>
        <?php }

        function yashica_poukazy_typ_poukazu_callback(array $args)
        {
        ?>
            <select class="poukaz_typ_poukazu_select" name="yashica_poukazy_options[poukaz_typ_poukazu_<?php echo $args['input_number']; ?>]" id="poukaz_typ_poukazu_<?php echo $args['input_number']; ?>">
                <option value="fixed_cart" <?php echo (isset($this->yashica_poukazy_options['poukaz_typ_poukazu_' . $args['input_number']]) && $this->yashica_poukazy_options['poukaz_typ_poukazu_' . $args['input_number']] == 'fixed_cart') ? 'selected' : ''; ?>>Pevná cena</option>
                <option value="percent" <?php echo (isset($this->yashica_poukazy_options['poukaz_typ_poukazu_' . $args['input_number']]) && $this->yashica_poukazy_options['poukaz_typ_poukazu_' . $args['input_number']] == 'percent') ? 'selected' : ''; ?>>Procentuální</option>
            </select>
        <?php }

        private function yashica_poukazy_img_exist($id)
        {
            return (get_attached_file($id)) ? true : false;
        }
        function poukaz_predpona_callback(array $args)
        {
            printf(
                '<input class="regular-text poukaz_predpona" type="text" placeholder="SK,KUPON,..." name="yashica_poukazy_options[poukaz_predpona_' . $args['input_number'] . ']" id="poukaz_predpona_' . $args['input_number'] . '" value="%s">',
                isset($this->yashica_poukazy_options['poukaz_predpona_' . $args['input_number']]) ? esc_attr($this->yashica_poukazy_options['poukaz_predpona_' . $args['input_number']]) : ''
            );
        }

        function yashica_poukazy_poukaz_img_callback(array $args)
        {
            $img_id = (isset($this->yashica_poukazy_options['poukaz_image_attachment_id_' . $args['input_number']]) && $this->yashica_poukazy_options['poukaz_image_attachment_id_' . $args['input_number']]) ? $this->yashica_poukazy_options['poukaz_image_attachment_id_' . $args['input_number']] : 0;
            if ($img_id && $this->yashica_poukazy_img_exist($img_id)) {
                $img_url = wp_get_attachment_image_url($img_id);
            } else {
                $img_url = '';
                $img_id = 0;
            }
        ?>
            <div class='image-preview-wrapper'>
                <img class="image-poukaz-preview" id='image-poukaz-preview-<?php echo $args['input_number']; ?>' src='<?php echo $img_url; ?>' style='<?php if (!$img_url) echo 'display:none;'; ?>'>
            </div>
            <button class="button upload_poukaz_image_button" id="upload_poukaz_image_<?php echo $args['input_number']; ?>_button" type="button"><?php _e('Nahrát poukaz'); ?></button>
            <input class="poukaz_image_attachment_id" type='hidden' name='yashica_poukazy_options[poukaz_image_attachment_id_<?php echo $args['input_number']; ?>]' id='poukaz_image_attachment_id_<?php echo $args['input_number']; ?>' value='<?php echo $img_id; ?>'>
<?php
        }

        function yashica_poukazy_generatePDF($poukaz_array, $nahled)
        {
            require_once __DIR__ . '/vendor/autoload.php';
            $img_path = get_attached_file($poukaz_array['img_id']);
            if (!$poukaz_array['delka']) {
                $poukaz_array['delka'] = YASHICA_POUKAZY_DEFAULT_DELKA_POUKAZU;
            }

            $code = $this->yashica_poukazy_generate_code($poukaz_array['predpona'], $poukaz_array['delka']);
            if (!$nahled) {
                $this->yashica_poukazy_generate_poukaz($code, $poukaz_array['typ'], $poukaz_array['hodnota'], $poukaz_array['delka_platnosti']);
            }
            $mpdf = new \Mpdf\Mpdf(
                [
                    'mode' => 'utf-8',
                    'tempDir' => WP_CONTENT_DIR . '/uploads/mpdftemp',
                ]
            );
            $mpdf->WriteHTML('<img src="' . $img_path . '">');
            $mpdf->WriteHTML('<div style="position:absolute;top:' . $poukaz_array['top'] . ';left:' . $poukaz_array['left'] . ';font-size:25px;font-family:Arial;">' . $code . '</div>');

            if ($nahled) {
                $pdfString = $mpdf->Output('', 'S');
                $pdfBase64 =  base64_encode($pdfString);
                return $pdfBase64;
            } else {
                $rok = date('Y');
                $poukaz_base_path = __DIR__ . '/poukazy/' . $rok;
                if (!file_exists($poukaz_base_path) && !is_dir($poukaz_base_path)) {
                    mkdir($poukaz_base_path);
                }
                $poukaz_path = $poukaz_base_path . '/poukaz_' . $poukaz_array['order_id'] . '_' . $code . '.pdf';
                $mpdf->Output($poukaz_path, 'F');
                return ['path' => $poukaz_path, 'code' => $code];
            }
        }
        function yashica_poukazy_nahledPoukazuAction()
        {
            $pdf = $this->yashica_poukazy_generatePDF(['img_id' => $_POST['img_id'], 'predpona' => $_POST['predpona'], 'delka' => $_POST['delka'], 'typ' => $_POST['typ'], 'top' => $_POST['top'], 'left' => $_POST['left']], true);
            echo json_encode(array('response' => $pdf));
            die();
        }
        function yashica_poukazy_generate_poukaz($code, $typ, $hodnota, $delka_platnosti)
        {

            $coupon = new WC_Coupon();
            $coupon->set_code($code);
            $coupon->set_discount_type($typ);
            $coupon->set_amount($hodnota);
            if ($typ == 'fixed_cart') {
                $coupon->set_minimum_amount($hodnota);
            }
            $coupon->set_usage_limit(1);
            if ($delka_platnosti) {
                $datum = new DateTime('now');
                $datum->modify('+' . $delka_platnosti . ' month');
                $coupon->set_date_expires($datum->format('d-m-Y'));
            }
            $coupon->save();
        }
        private function yashica_poukazy_generate_code($predpona, $delka)
        {

            $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            do {
                $code = $predpona;
                for ($i = 0; $i < $delka; $i++) {
                    $code .= $characters[rand(0, $charactersLength - 1)];
                }
            } while (wc_get_coupon_id_by_code($code) !== 0);

            return $code;
        }
        //UPDATE
        public function yashica_poukazy_plugin_info($res, $action, $args)
        {
            if ('plugin_information' !== $action) {
                return $res;
            }

            if (plugin_basename(__DIR__) !== $args->slug) {
                return $res;
            }

            $remote = wp_remote_get(
                YASHICA_DASHBOARD_UPDATE_INFO_FILE,
                array(
                    'timeout' => 10,
                    'headers' => array(
                        'Accept' => 'application/json'
                    )
                )
            );

            if (
                is_wp_error($remote)
                || 200 !== wp_remote_retrieve_response_code($remote)
                || empty(wp_remote_retrieve_body($remote))
            ) {
                return $res;
            }

            $remote = json_decode(wp_remote_retrieve_body($remote));

            $res = new stdClass();
            $res->name = $remote->name;
            $res->slug = $remote->slug;
            $res->author = $remote->author;
            $res->author_profile = $remote->author_profile;
            $res->version = $remote->version;
            $res->tested = $remote->tested;
            $res->requires = $remote->requires;
            $res->requires_php = $remote->requires_php;
            $res->download_link = $remote->download_url;
            $res->trunk = $remote->download_url;
            $res->last_updated = $remote->last_updated;
            $res->sections = array(
                'description' => $remote->sections->description,
                'installation' => $remote->sections->installation,
                'changelog' => $remote->sections->changelog
            );

            return $res;
        }
        public function yashica_poukazy_push_update($transient)
        {

            if (empty($transient->checked)) {
                return $transient;
            }

            $remote = wp_remote_get(
                YASHICA_POUKAZY_UPDATE_INFO_FILE,
                array(
                    'timeout' => 10,
                    'headers' => array(
                        'Accept' => 'application/json'
                    )
                )
            );

            if (
                is_wp_error($remote)
                || 200 !== wp_remote_retrieve_response_code($remote)
                || empty(wp_remote_retrieve_body($remote))
            ) {
                return $transient;
            }

            $remote = json_decode(wp_remote_retrieve_body($remote));

            if (
                $remote
                && version_compare($transient->checked[plugin_basename(__FILE__)], $remote->version, '<')
                && version_compare($remote->requires, get_bloginfo('version'), '<')
                && version_compare($remote->requires_php, PHP_VERSION, '<')
            ) {

                $res = new stdClass();
                $res->slug = $remote->slug;
                $res->plugin = plugin_basename(__FILE__);
                $res->new_version = $remote->version;
                $res->tested = $remote->tested;
                $res->package = $remote->download_url;
                $transient->response[$res->plugin] = $res;
            }

            return $transient;
        }
    }
}
if (class_exists('WooCommerce')) {
    $yashica_poukazy = new YashicaPoukazy();
}
