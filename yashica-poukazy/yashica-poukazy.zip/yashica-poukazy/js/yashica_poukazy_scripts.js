var ajaxLock = true;
jQuery('.poukaz_nahled_btn').on('click', function () {
    if (ajaxLock) {
        ajaxLock = false;
        const this_table = jQuery(this).closest('table');
        var img_id = this_table.find('.poukaz_image_attachment_id').val();
        if (img_id != '') {
            jQuery.ajax({
                type: 'POST',
                dataType: 'JSON',
                url: yashica_poukazy_ajax_object.ajax_url,
                data: {
                    action: 'yashica_poukazy_nahledPoukazuAction',
                    img_id: img_id,
                    predpona: this_table.find('.poukaz_predpona').val(),
                    delka: this_table.find('.poukaz_delka').val(),
                    top: this_table.find('.poukaz_pozice_top').val(),
                    left: this_table.find('.poukaz_pozice_left').val()
                },
                success: function (res) {

                    if (res['response']) {

                        var byteCharacters = atob(res['response']);
                        var byteNumbers = new Array(byteCharacters.length);
                        for (var i = 0; i < byteCharacters.length; i++) {
                            byteNumbers[i] = byteCharacters.charCodeAt(i);
                        }
                        var byteArray = new Uint8Array(byteNumbers);
                        var file = new Blob([byteArray], { type: 'application/pdf;base64' });
                        var fileURL = URL.createObjectURL(file);
                        window.open(fileURL);
                    }

                },
                beforeSend: function () {

                },
                complete: function () {

                },
                error: function (xhr, status, error) {
                    console.log(xhr);
                    console.log(status);
                    console.log(error);
                },
            });
        }
        ajaxLock = true;
    }

});
jQuery('.poukaz_activate').change(function () {
    var this_table = jQuery(this).closest('table');
    var display_value = 'none';
    if (jQuery(this).prop('checked')) {
        this_table.find('.poukaz_hodnota').attr('required', 'required');
        this_table.find('.poukaz_produkt_id_select').attr('required', true);
        display_value = 'table-row';
    } else {
        this_table.find('.poukaz_hodnota').removeAttr('required');
        this_table.find('.poukaz_produkt_id_select').removeAttr('required');
    }
    this_table.find('tr').each(function (index) {
        if (index != 0) {
            jQuery(this).css('display', display_value);
        }
    });
});
function onInitFields_Yashica_poukazy() {
    jQuery('.poukaz_activate').each(function () {
        var this_table = jQuery(this).closest('table');
        var display_value = 'none';
        if (jQuery(this).prop('checked')) {
            this_table.find('.poukaz_hodnota').attr('required', 'required');
            this_table.find('.poukaz_produkt_id_select').attr('required', 'required');
            display_value = 'table-row';
        } else {
            this_table.find('.poukaz_hodnota').removeAttr('required');
            this_table.find('.poukaz_produkt_id_select').removeAttr('required');
        }
        this_table.find('tr').each(function (index) {
            if (index != 0) {
                jQuery(this).css('display', display_value);
            }
        });
    });

}
jQuery(document).ready(function ($) {
    
    onInitFields_Yashica_poukazy();
    $('.poukaz_produkt_id_select').select2();
    $('.poukaz_typ_poukazu_select').select2({
        minimumResultsForSearch: Infinity
    });
    // Define a variable wkMedia
    var wkMedia;
    var upload_btn = $(this);
    $('.upload_poukaz_image_button').click(function (e) {
        upload_btn = $(this);
        e.preventDefault();

        // If the upload object has already been created, reopen the dialog
        if (wkMedia) {
            wkMedia.open();
            return;
        }
        // Extend the wp.media object
        wkMedia = wp.media.frames.file_frame = wp.media({
            title: 'Select media',
            button: {
                text: 'Select media'
            }, multiple: false
        });
        // When a file is selected, grab the URL and set it as the text field's value
        wkMedia.on('select', function () {
            var attachment = wkMedia.state().get('selection').first().toJSON();
            const poukaz_table = upload_btn.closest('table');
            var img_prev = poukaz_table.find('.image-poukaz-preview');
            img_prev.attr('src', attachment.url);
            img_prev.css('display', 'block');

            poukaz_table.find('.poukaz_image_attachment_id').val(attachment.id)
            poukaz_table.find('.poukaz_hodnota').attr('required', 'required');
        });
        // Open the upload dialog
        wkMedia.open();
    });
});