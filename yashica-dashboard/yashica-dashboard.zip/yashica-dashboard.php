<?php
/*
 * Plugin Name:       Yashica Dashboard
 * Description:       Nástěnka Yashica Digital
 * Version:           1.2.5
 * Author:            Yashica Digital s.r.o.
 * Author URI:        https://yashica-digital.cz
 * Text Domain:       yashica-digital
 */

defined('ABSPATH') or die('Really?');

if (!class_exists('YashicaDashboard')) {
    //DEFAULT EMAIL
    define('YASHICA_DASHBOARD_EMAIL', 'ticket@yashica-digital.cz');
    //DEFAULT IFRAME
    define('YASHICA_DASHBOARD_IFRAME_URL', 'https://www.yashica-digital.cz/dashboard/');
    //UPDATE INFO FILE
    define('YASHICA_DASHBOARD_UPDATE_INFO_FILE', 'https://raw.githubusercontent.com/YashicaDigital-Development/yashica-plugins/main/yashica-dashboard/info.json');
    class YashicaDashboard
    {
        private $yashica_dashboard_options;

        public function __construct()
        {
            add_action('admin_enqueue_scripts', array($this, 'yashica_dashboard_link_assets'));
            add_action('admin_menu', array($this, 'yashica_dashboard_add_plugin_page'));
            add_action('admin_init', array($this, 'yashica_dashboard_page_init'));
            add_action('wp_dashboard_setup', array($this, 'yashica_dashboard_remove_dashboard_widgets'), 100);
            remove_action('welcome_panel', 'wp_welcome_panel');
            add_action('welcome_panel', array($this, 'yashica_dashboard_wp_welcome_panel'));
            add_filter('admin_footer_text', array($this, 'yashica_dashboard_update_footer_admin'));
            add_filter('plugins_api', array($this, 'yashica_dashboard_plugin_info'), 20, 3);
            add_filter('site_transient_update_plugins', array($this, 'yashica_dashboard_push_update'));
            register_deactivation_hook(__FILE__,  array($this, 'yashica_dashboard_on_deactivation'));
            //register_activation_hook(__FILE__,  array($this, 'yashica_dashboard_on_activation'));
        }

        /* Vymaže všechny widgety z nástěnky */
        public function yashica_dashboard_remove_dashboard_widgets()
        {
            global $wp_meta_boxes;
            $wp_meta_boxes = [];
        }


        /* Načte vlastní welcome panel */
        public function yashica_dashboard_wp_welcome_panel()
        {
            $this->yashica_dashboard_options = get_option('yashica_dashboard_options');
            $email = (isset($this->yashica_dashboard_options['support_email']) && $this->yashica_dashboard_options['support_email'] !== '')
                ? $this->yashica_dashboard_options['support_email']
                : YASHICA_DASHBOARD_EMAIL ?>
            <div class="yashica_dashboard-welcome-panel-content">
                <div class="flex justify-between items-center">
                    <div class="flex gap-16 items-center">
                        <h2 class="!text-4xl"><?php _e('Základní informace', 'yashica-dashboard'); ?></h2>
                        <div class="text-lg flex gap-4">
                            <span><?= __('Záruka:', 'yashica-dashboard') ?></span>
                            <span><?= isset($this->yashica_dashboard_options['datum_spusteni']) ? ($this->yashica_dashboard_get_warranty_days() ? __('ano', 'yashica-dashboard') : __('ne', 'yashica-dashboard')) : __('neuvedeno', 'yashica-dashboard') ?></span>
                        </div>
                        <div class="text-lg flex gap-4">
                            <span><?= __('Datum výroby:', 'yashica-dashboard') ?></span>
                            <span><?= isset($this->yashica_dashboard_options['datum_spusteni']) && $this->yashica_dashboard_options['datum_spusteni'] ? date('d.m.Y', strtotime($this->yashica_dashboard_options['datum_spusteni'])) : __('neuvedeno', 'yashica-dashboard') ?></span>
                        </div>
                        <a href="mailto:<?= $email ?>" class="px-4 py-2 text-lg bg-[#D0FE1D] !text-black hover:bg-black hover:!text-[#D0FE1D] transition-all duration-300">
                            <?= __('Kontaktovat podporu', 'yashica-dashboard') ?>
                        </a>
                    </div>
                    <a href="https://www.yashica-digital.cz/" target="_blank">
                        <img src="<?= plugin_dir_url(__FILE__) ?>/img/logo.svg" alt="Yashica Digital logo" class="max-w-32 w-full">
                    </a>
                </div>
                <?php if (isset($this->yashica_dashboard_options['zobrazit_iframe'])) :
                    $url = (isset($this->yashica_dashboard_options['iframe_url']) && $this->yashica_dashboard_options['iframe_url'] !== '')
                        ? $this->yashica_dashboard_options['iframe_url']
                        : YASHICA_DASHBOARD_IFRAME_URL ?>
                    <div class="h-[80vh] mt-8 pb-8">
                        <iframe src="<?= $url ?>" frameborder="0" height="100%" width="100%"></iframe>
                    </div>
                <?php endif ?>
            </div>
        <?php
        }

        /* Načte logo url */
        public function yashica_dashboard_get_logo_url()
        {
            return plugin_dir_url(__FILE__) . 'YD_black_logo.png';
        }
        /* Get dny v zaruce */
        public function yashica_dashboard_get_warranty_days()
        {
            if (isset($this->yashica_dashboard_options['datum_spusteni'])) :
                $start_date = new DateTime($this->yashica_dashboard_options['datum_spusteni']);
                $now = new DateTime(date('Y-m-d'));
                $warranty_date = $start_date;
                $pocet_let = 1;
                if ($this->yashica_dashboard_options['pocet_roku_zaruky']) {
                    $pocet_let = $this->yashica_dashboard_options['pocet_roku_zaruky'];
                }
                $warranty_date = $warranty_date->add(new DateInterval("P" . $pocet_let . "Y"));
                if ($now < $warranty_date) {
                    return true;
                }
            endif;
            return false;
        }
        /* Admin patička */
        public function yashica_dashboard_update_footer_admin()
        {
            echo 'Powered by <a href="https://www.yashica-digital.cz/" target="_blank">YASHICA DIGITAL</a> and ';
        }

        /* Link sc ripts, styles */
        public function yashica_dashboard_link_assets()
        {
            wp_enqueue_style('yashica_dashboard_styles', plugin_dir_url(__FILE__) . 'css/tailwind.css');
            wp_enqueue_script('yashica_dashboard_scripts', plugin_dir_url(__FILE__) . 'js/yashica_dashboard_scripts.js', array('jquery'), false, true);
            wp_localize_script(
                'yashica_dashboard_scripts',
                'yashica_dashboard_ajax_object',
                array('ajax_url' => admin_url('admin-ajax.php'))
            );
        }

        /* SETTINGS PAGE */
        public function yashica_dashboard_add_plugin_page()
        {
            add_dashboard_page(
                'Yashica Digital nástěnka - nastavení', // page_title
                'Yashica Digital nástěnka - nastavení', // menu_title
                'manage_options', // capability
                'yashica-digital-dashboard', // menu_slug
                array($this, 'yashica_dashboard_create_admin_page') // function
            );
        }
        public function yashica_dashboard_create_admin_page()
        {

            $this->yashica_dashboard_options = get_option('yashica_dashboard_options'); ?>
            <div class="wrap">
                <h1>Yashica Digital nástěnka - nastavení</h1>
                <p>Nastavení nástěnky.</p>
                <?php settings_errors(); ?>

                <form method="post" action="options.php">
                    <?php
                    settings_fields('yashica_dashboard_options_group');
                    do_settings_sections('yashica-dashboard-admin');
                    submit_button();
                    ?>
                </form>
            </div>
<?php   }
        public function yashica_dashboard_page_init()
        {
            $role_object = get_role('editor');
            $role_object->add_cap('edit_theme_options');
            register_setting(
                'yashica_dashboard_options_group',
                'yashica_dashboard_options',
                array($this, 'yashica_dashboard_sanitize')
            );

            add_settings_section(
                'yashica_dashboard_setting_section',
                'Nastavení',
                array($this, 'yashica_dashboard_section_info'),
                'yashica-dashboard-admin'
            );
            add_settings_field(
                'datum_spusteni',
                'Datum spuštění',
                array($this, 'datum_spusteni_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'support_email',
                'Email',
                array($this, 'support_email_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );

            add_settings_field(
                'zobrazit_formular',
                'Zobrazit formulář',
                array($this, 'zobrazit_formular_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'pocet_roku_zaruky',
                'Počet roků záruky',
                array($this, 'pocet_roku_zaruky_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'zobrazit_zaruku',
                'Zobrazit záruku',
                array($this, 'zobrazit_zaruku_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'iframe_url',
                'Iframe URL',
                array($this, 'iframe_url_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'zobrazit_iframe',
                'Zobrazit iframe',
                array($this, 'zobrazit_iframe_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            if (get_option('yashica_dashboard_options') === false)
                add_option('yashica_dashboard_options', array('zobrazit_iframe' => '1'));
        }
        public function yashica_dashboard_sanitize($input)
        {
            $sanitary_values = array();
            if (isset($input['pocet_roku_zaruky'])) {
                $sanitary_values['pocet_roku_zaruky'] = sanitize_text_field($input['pocet_roku_zaruky']);
            }
            if (isset($input['support_email'])) {
                $sanitary_values['support_email'] = sanitize_text_field($input['support_email']);
            }
            if (isset($input['iframe_url'])) {
                $sanitary_values['iframe_url'] = sanitize_text_field($input['iframe_url']);
            }
            if (isset($input['zobrazit_iframe'])) {
                $sanitary_values['zobrazit_iframe'] = $input['zobrazit_iframe'];
            }
            if (isset($input['zobrazit_formular'])) {
                $sanitary_values['zobrazit_formular'] = $input['zobrazit_formular'];
            }

            if (isset($input['zobrazit_zaruku'])) {
                $sanitary_values['zobrazit_zaruku'] = $input['zobrazit_zaruku'];
            }
            if (isset($input['datum_spusteni'])) {
                $sanitary_values['datum_spusteni'] = $input['datum_spusteni'];
            }
            return $sanitary_values;
        }
        public function yashica_dashboard_section_info()
        {
        }
        public function pocet_roku_zaruky_callback()
        {
            printf(
                '<input class="regular-text" type="number" name="yashica_dashboard_options[pocet_roku_zaruky]" placeholder="1" id="pocet_roku_zaruky" value="%s">',
                isset($this->yashica_dashboard_options['pocet_roku_zaruky']) ? esc_attr($this->yashica_dashboard_options['pocet_roku_zaruky']) : ''
            );
        }
        public function datum_spusteni_callback()
        {
            printf(
                '<input class="regular-text" type="date" name="yashica_dashboard_options[datum_spusteni]" id="support_email" value="%s">',
                isset($this->yashica_dashboard_options['datum_spusteni']) ? esc_attr($this->yashica_dashboard_options['datum_spusteni']) : ''
            );
        }
        public function support_email_callback()
        {
            printf(
                '<input class="regular-text" type="text" placeholder="ticket@yashica-digital.cz" name="yashica_dashboard_options[support_email]" id="support_email" value="%s">',
                isset($this->yashica_dashboard_options['support_email']) ? esc_attr($this->yashica_dashboard_options['support_email']) : ''
            );
        }
        public function iframe_url_callback()
        {
            printf(
                '<input class="regular-text" type="text" placeholder="https://www.yashica-digital.cz" name="yashica_dashboard_options[iframe_url]" id="iframe_url" value="%s">',
                isset($this->yashica_dashboard_options['iframe_url']) ? esc_attr($this->yashica_dashboard_options['iframe_url']) : ''
            );
        }
        public function zobrazit_iframe_callback()
        {
            printf(
                '<input type="checkbox" name="yashica_dashboard_options[zobrazit_iframe]" id="zobrazit_iframe" value="1" %s>',
                (isset($this->yashica_dashboard_options['zobrazit_iframe']) && $this->yashica_dashboard_options['zobrazit_iframe'] == 1) ? 'checked' : ''
            );
        }
        public function zobrazit_formular_callback()
        {
            printf(
                '<input type="checkbox" name="yashica_dashboard_options[zobrazit_formular]" id="zobrazit_formular" value="1" %s>',
                (isset($this->yashica_dashboard_options['zobrazit_formular']) && $this->yashica_dashboard_options['zobrazit_formular'] == 1) ? 'checked' : ''
            );
        }
        public function zobrazit_zaruku_callback()
        {
            printf(
                '<input type="checkbox" name="yashica_dashboard_options[zobrazit_zaruku]" id="zobrazit_zaruku" value="1" %s>',
                (isset($this->yashica_dashboard_options['zobrazit_zaruku']) && $this->yashica_dashboard_options['zobrazit_zaruku'] == 1) ? 'checked' : ''
            );
        }

        public function yashica_dashboard_on_activation()
        {
        }
        public function yashica_dashboard_on_deactivation()
        {
        }
        //UPDATE
        public function yashica_dashboard_plugin_info($res, $action, $args)
        {


            if ('plugin_information' !== $action) {
                return $res;
            }

            if (plugin_basename(__DIR__) !== $args->slug) {
                return $res;
            }

            $remote = wp_remote_get(
                YASHICA_DASHBOARD_UPDATE_INFO_FILE,
                array(
                    'timeout' => 10,
                    'headers' => array(
                        'Accept' => 'application/json'
                    )
                )
            );

            if (
                is_wp_error($remote)
                || 200 !== wp_remote_retrieve_response_code($remote)
                || empty(wp_remote_retrieve_body($remote))
            ) {
                return $res;
            }

            $remote = json_decode(wp_remote_retrieve_body($remote));

            $res = new stdClass();
            $res->name = $remote->name;
            $res->slug = $remote->slug;
            $res->author = $remote->author;
            $res->author_profile = $remote->author_profile;
            $res->version = $remote->version;
            $res->tested = $remote->tested;
            $res->requires = $remote->requires;
            $res->requires_php = $remote->requires_php;
            $res->download_link = $remote->download_url;
            $res->trunk = $remote->download_url;
            $res->last_updated = $remote->last_updated;
            $res->sections = array(
                'description' => $remote->sections->description,
                'installation' => $remote->sections->installation,
                'changelog' => $remote->sections->changelog
            );

            return $res;
        }
        public function yashica_dashboard_push_update($transient)
        {

            if (empty($transient->checked) || !isset($transient->checked[plugin_basename(__FILE__)])) {
                return $transient;
            }

            $remote = wp_remote_get(
                YASHICA_DASHBOARD_UPDATE_INFO_FILE,
                array(
                    'timeout' => 10,
                    'headers' => array(
                        'Accept' => 'application/json'
                    )
                )
            );

            if (
                is_wp_error($remote)
                || 200 !== wp_remote_retrieve_response_code($remote)
                || empty(wp_remote_retrieve_body($remote))
            ) {
                return $transient;
            }

            $remote = json_decode(wp_remote_retrieve_body($remote));

            if (
                $remote
                && version_compare($transient->checked[plugin_basename(__FILE__)], $remote->version, '<')
                && version_compare($remote->requires, get_bloginfo('version'), '<')
                && version_compare($remote->requires_php, PHP_VERSION, '<')
            ) {

                $res = new stdClass();
                $res->slug = $remote->slug;
                $res->plugin = plugin_basename(__FILE__);
                $res->new_version = $remote->version;
                $res->tested = $remote->tested;
                $res->package = $remote->download_url;
                $transient->response[$res->plugin] = $res;
            }

            return $transient;
        }
    }
}
if (is_admin())
    $yashica_dashboard = new YashicaDashboard();
