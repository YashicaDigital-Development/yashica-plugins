jQuery('#yashica_dashboard_show_form_btn').on('click', function () {
    form = jQuery('#yashica_dashboard_contact_form');
    form.toggleClass('active');
    jQuery(this).css('display','none');
	jQuery('#yashica_dashboard_hide_form_btn').fadeIn();
    jQuery('#yashica_dashboard_contact_form').fadeIn();
});
jQuery('#yashica_dashboard_hide_form_btn').on('click', function () {
    form = jQuery('#yashica_dashboard_contact_form');
    form.toggleClass('active');
	jQuery(this).css('display','none');
	jQuery('#yashica_dashboard_show_form_btn').fadeIn();
    jQuery('#yashica_dashboard_contact_form').fadeOut();
    
});