<?php
/*
 * Plugin Name:       Yashica Dashboard
 * Description:       Nástěnka Yashica Digital
 * Version:           1.1.3
 * Author:            Yashica Digital s.r.o.
 * Author URI:        https://yashica-digital.cz
 * Text Domain:       yashica-digital
 */

defined('ABSPATH') or die('Really?');

//DEFAULT EMAIL
define('YASHICA_DASHBOARD_EMAIL', 'ticket@yashica-digital.cz');
//DEFAULT IFRAME
define('YASHICA_DASHBOARD_IFRAME_URL', 'https://www.yashica-digital.cz/dashboard/');
//TEXTDOMAIN
define('YASHICA_DASHBOARD_TEXTDOMAIN', 'yashica-dashboard');
if (!class_exists('YashicaDashboard')) {
    class YashicaDashboard
    {
        private $yashica_dashboard_options;

        public function __construct()
        {
            add_action('admin_enqueue_scripts', array($this, 'yashica_dashboard_link_assets'));
            add_action('admin_menu', array($this, 'yashica_dashboard_add_plugin_page'));
            add_action('admin_init', array($this, 'yashica_dashboard_page_init'));
            add_action('wp_dashboard_setup', array($this, 'yashica_dashboard_remove_dashboard_widgets'), 100);
            remove_action('welcome_panel', 'wp_welcome_panel');
            add_action('welcome_panel', array($this, 'yashica_dashboard_wp_welcome_panel'));
            add_filter('admin_footer_text', array($this, 'yashica_dashboard_update_footer_admin'));
            add_action('activated_plugin', array($this, 'yashica_dashboard_plugin_activate'));
        }

        /* Vymaže všechny widgety z nástěnky */
        public function yashica_dashboard_remove_dashboard_widgets()
        {
            global $wp_meta_boxes;
            $wp_meta_boxes = [];
        }


        /* Načte vlastní welcome panel */
        public function yashica_dashboard_wp_welcome_panel()
        {
            $this->yashica_dashboard_options = get_option('yashica_dashboard_option_name');
            $email = YASHICA_DASHBOARD_EMAIL;
            if (isset($this->yashica_dashboard_options['support_email']) && $this->yashica_dashboard_options['support_email'] !== '') $email = $this->yashica_dashboard_options['support_email'];
?>
            <div class="yashica_dashboard-welcome-panel-content">
                <?php if ($logo_url = $this->yashica_dashboard_get_logo_url()) : ?>
                    <img class="yashica_dashboard_logo" src="<?php echo $logo_url; ?>" alt="Yashica Digital s.r.o.">
                <?php endif; ?>
                <h2 class="yashica_dashboard_title"><?php _e('Vítejte na webu', YASHICA_DASHBOARD_TEXTDOMAIN) . ' ' . bloginfo('name'); ?>!</h2>
                <p class="about-description"><?php _e('V případě dotazů či podpory nás neváhejte kontaktovat na', YASHICA_DASHBOARD_TEXTDOMAIN); ?> <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
                    <?php
                    if (isset($this->yashica_dashboard_options['zobrazit_formular'])) :
                        echo ' ' . __('nebo využijte kontaktní formulář níže.', YASHICA_DASHBOARD_TEXTDOMAIN); ?></p>
                <div><span class="yashica_dashboard_btn" id="yashica_dashboard_show_form_btn"><?php _e('Zobrazit formulář', YASHICA_DASHBOARD_TEXTDOMAIN); ?></span><span class="yashica_dashboard_btn" id="yashica_dashboard_hide_form_btn" style="display:none;"><?php _e('Skrýt formulář', YASHICA_DASHBOARD_TEXTDOMAIN); ?></span></div>
                <div id="yashica_dashboard_contact_form" style="display:none;">
                    <iframe src="https://forms.monday.com/forms/embed/efe54cab8efe76cbea205046a783002c?r=use1" height="1300"></iframe>
                </div>

            <?php

                    endif; ?>
            <?php if (isset($this->yashica_dashboard_options['zobrazit_iframe'])) :
                $url = YASHICA_DASHBOARD_IFRAME_URL;
                if (isset($this->yashica_dashboard_options['iframe_url']) && $this->yashica_dashboard_options['iframe_url'] !== '') $url = $this->yashica_dashboard_options['iframe_url']; ?>
                <div id="yashica_iframe_wrap" style="margin-top:50px;">
                    <iframe src="<?php echo $url; ?>" height="500"></iframe>
                </div>
            <?php endif; ?>
            <?php if (isset($this->yashica_dashboard_options['zobrazit_zaruku']) && isset($this->yashica_dashboard_options['datum_spusteni'])) : ?>
                <div class="yashica_dashboard_warranty_wrap">
                    <p>
                        <?php
                        $zaruka_dni = $this->yashica_dashboard_get_warranty_days();
                        if ($zaruka_dni > 31) {
                            _e('Váš web je u nás stále v záruce.', YASHICA_DASHBOARD_TEXTDOMAIN);
                        } else if ($zaruka_dni == 0) {
                            _e('Vašemu webu vypršela záruka.', YASHICA_DASHBOARD_TEXTDOMAIN);
                        } else if ($zaruka_dni == 1) {
                            echo __('Vašemu webu zbývá', YASHICA_DASHBOARD_TEXTDOMAIN) . ' ' . $zaruka_dni . ' ' . __('den záruky.', YASHICA_DASHBOARD_TEXTDOMAIN);
                        } else if ($zaruka_dni < 5) {
                            echo __('Vašemu webu zbývájí', YASHICA_DASHBOARD_TEXTDOMAIN) . ' ' . $zaruka_dni . ' ' . __('dny záruky.', YASHICA_DASHBOARD_TEXTDOMAIN);
                        } else {
                            echo __('Vašemu webu zbývá', YASHICA_DASHBOARD_TEXTDOMAIN) . ' ' . $zaruka_dni . ' ' . __('dnů záruky.', YASHICA_DASHBOARD_TEXTDOMAIN);
                        }
                        ?>
                    </p>
                </div>
            <?php endif; ?>
            </div>
        <?php
        }

        /* Načte logo url */
        public function yashica_dashboard_get_logo_url()
        {
            return plugin_dir_url(__FILE__) . 'YD_black_logo.png';
        }
        /* Get dny v zaruce */
        public function yashica_dashboard_get_warranty_days()
        {
            if (isset($this->yashica_dashboard_options['datum_spusteni'])) :
                $start_date = new DateTime($this->yashica_dashboard_options['datum_spusteni']);
                $now = new DateTime(date('Y-m-d'));
                $warranty_date = $start_date;
                $warranty_date = $warranty_date->add(new DateInterval("P" . $this->yashica_dashboard_options['pocet_roku_zaruky'] . "Y"));
                if ($now < $warranty_date) {
                    return $now->diff($warranty_date)->format("%a");
                }
            endif;
            return 0;
        }
        /* Admin patička */
        public function yashica_dashboard_update_footer_admin()
        {
            echo 'Powered by <a href="https://www.yashica-digital.cz/" target="_blank">YASHICA DIGITAL</a> and ';
        }

        /* Link sc ripts, styles */
        public function yashica_dashboard_link_assets()
        {
            wp_enqueue_style('yashica_dashboard_styles', plugin_dir_url(__FILE__) . 'css/yashica_dashboard_styles.css');
            wp_enqueue_script('yashica_dashboard_scripts', plugin_dir_url(__FILE__) . 'js/yashica_dashboard_scripts.js', array('jquery'), false, true);
            wp_localize_script(
                'yashica_dashboard_scripts',
                'yashica_dashboard_ajax_object',
                array('ajax_url' => admin_url('admin-ajax.php'))
            );
        }

        /* SETTINGS PAGE */
        public function yashica_dashboard_add_plugin_page()
        {
            add_dashboard_page(
                'Yashica Digital nástěnka', // page_title
                'Yashica Digital nástěnka', // menu_title
                'manage_options', // capability
                'yashica-digital-dashboard', // menu_slug
                array($this, 'yashica_dashboard_create_admin_page') // function
            );
        }
        public function yashica_dashboard_create_admin_page()
        {

            $this->yashica_dashboard_options = get_option('yashica_dashboard_option_name'); ?>
            <div class="wrap">
                <h1>Yashica Digital nástěnka</h1>
                <p>Nastavení nástěnky.</p>
                <?php settings_errors(); ?>

                <form method="post" action="options.php">
                    <?php
                    settings_fields('yashica_dashboard_option_group');
                    do_settings_sections('yashica-dashboard-admin');
                    submit_button();
                    ?>
                </form>
            </div>
<?php   }
        public function yashica_dashboard_page_init()
        {
            $role_object = get_role('editor');
            $role_object->add_cap('edit_theme_options');
            register_setting(
                'yashica_dashboard_option_group', // option_group
                'yashica_dashboard_option_name', // option_name
                array($this, 'yashica_dashboard_sanitize') // sanitize_callback
            );

            add_settings_section(
                'yashica_dashboard_setting_section', // id
                'Nastavení', // title
                array($this, 'yashica_dashboard_section_info'), // callback
                'yashica-dashboard-admin' // page
            );
            add_settings_field(
                'datum_spusteni', // id
                'Datum spuštění', // title
                array($this, 'datum_spusteni_callback'), // callback
                'yashica-dashboard-admin', // page
                'yashica_dashboard_setting_section' // section
            );
            add_settings_field(
                'support_email',
                'Email',
                array($this, 'support_email_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );

            add_settings_field(
                'zobrazit_formular',
                'Zobrazit formulář',
                array($this, 'zobrazit_formular_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'pocet_roku_zaruky',
                'Počet roků záruky',
                array($this, 'pocet_roku_zaruky_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'zobrazit_zaruku',
                'Zobrazit záruku',
                array($this, 'zobrazit_zaruku_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'iframe_url',
                'Iframe URL',
                array($this, 'iframe_url_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
            add_settings_field(
                'zobrazit_iframe',
                'Zobrazit iframe',
                array($this, 'zobrazit_iframe_callback'),
                'yashica-dashboard-admin',
                'yashica_dashboard_setting_section'
            );
        }
        public function yashica_dashboard_sanitize($input)
        {
            $sanitary_values = array();
            if (isset($input['pocet_roku_zaruky'])) {
                $sanitary_values['pocet_roku_zaruky'] = sanitize_text_field($input['pocet_roku_zaruky']);
            }
            if (isset($input['support_email'])) {
                $sanitary_values['support_email'] = sanitize_text_field($input['support_email']);
            }
            if (isset($input['iframe_url'])) {
                $sanitary_values['iframe_url'] = sanitize_text_field($input['iframe_url']);
            }
            if (isset($input['zobrazit_iframe'])) {
                $sanitary_values['zobrazit_iframe'] = $input['zobrazit_iframe'];
            }
            if (isset($input['zobrazit_formular'])) {
                $sanitary_values['zobrazit_formular'] = $input['zobrazit_formular'];
            }

            if (isset($input['zobrazit_zaruku'])) {
                $sanitary_values['zobrazit_zaruku'] = $input['zobrazit_zaruku'];
            }
            if (isset($input['datum_spusteni'])) {
                $sanitary_values['datum_spusteni'] = $input['datum_spusteni'];
            }
            return $sanitary_values;
        }
        public function yashica_dashboard_section_info()
        {
        }
        public function pocet_roku_zaruky_callback()
        {
            printf(
                '<input class="regular-text" type="number" name="yashica_dashboard_option_name[pocet_roku_zaruky]" placeholder="1" id="pocet_roku_zaruky" value="%s">',
                isset($this->yashica_dashboard_options['pocet_roku_zaruky']) ? esc_attr($this->yashica_dashboard_options['pocet_roku_zaruky']) : ''
            );
        }
        public function datum_spusteni_callback()
        {
            printf(
                '<input class="regular-text" type="date" name="yashica_dashboard_option_name[datum_spusteni]" id="support_email" value="%s">',
                isset($this->yashica_dashboard_options['datum_spusteni']) ? esc_attr($this->yashica_dashboard_options['datum_spusteni']) : ''
            );
        }
        public function support_email_callback()
        {
            printf(
                '<input class="regular-text" type="text" placeholder="ticket@yashica-digital.cz" name="yashica_dashboard_option_name[support_email]" id="support_email" value="%s">',
                isset($this->yashica_dashboard_options['support_email']) ? esc_attr($this->yashica_dashboard_options['support_email']) : ''
            );
        }
        public function iframe_url_callback()
        {
            printf(
                '<input class="regular-text" type="text" placeholder="https://www.yashica-digital.cz" name="yashica_dashboard_option_name[iframe_url]" id="iframe_url" value="%s">',
                isset($this->yashica_dashboard_options['iframe_url']) ? esc_attr($this->yashica_dashboard_options['iframe_url']) : ''
            );
        }
        public function zobrazit_iframe_callback()
        {
            printf(
                '<input type="checkbox" name="yashica_dashboard_option_name[zobrazit_iframe]" id="zobrazit_iframe" value="zobrazit_iframe" %s>',
                (isset($this->yashica_dashboard_options['zobrazit_iframe']) && $this->yashica_dashboard_options['zobrazit_iframe'] === 'zobrazit_iframe') ? 'checked' : ''
            );
        }
        public function zobrazit_formular_callback()
        {
            printf(
                '<input type="checkbox" name="yashica_dashboard_option_name[zobrazit_formular]" id="zobrazit_formular" value="zobrazit_formular" %s>',
                (isset($this->yashica_dashboard_options['zobrazit_formular']) && $this->yashica_dashboard_options['zobrazit_formular'] === 'zobrazit_formular') ? 'checked' : ''
            );
        }
        public function zobrazit_zaruku_callback()
        {
            printf(
                '<input type="checkbox" name="yashica_dashboard_option_name[zobrazit_zaruku]" id="zobrazit_zaruku" value="zobrazit_zaruku" %s>',
                (isset($this->yashica_dashboard_options['zobrazit_zaruku']) && $this->yashica_dashboard_options['zobrazit_zaruku'] === 'zobrazit_zaruku') ? 'checked' : ''
            );
        }

        public static function yashica_dashboard_plugin_activate()
        {
        }
    }
}
if (is_admin())
    $yashica_dashboard = new YashicaDashboard();
