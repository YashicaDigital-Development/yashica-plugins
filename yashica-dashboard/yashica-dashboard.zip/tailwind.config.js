/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './*.php',
    './*.js',
  ],
  blocklist: [
    'fixed',
    'collapse',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

